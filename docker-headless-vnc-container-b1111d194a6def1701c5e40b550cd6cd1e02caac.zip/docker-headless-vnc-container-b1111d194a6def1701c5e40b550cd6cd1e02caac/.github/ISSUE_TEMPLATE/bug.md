---
name: Bug report
about: Create a bug report to help us enhance our images
---

**Image**

**Tag**

**Short overview**

**Detailed error description**

**Additional content**
> Please provide any (mandatory) additional data to reproduce the error (custom Dockerfiles etc.)